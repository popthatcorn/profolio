$(document).ready(function(){
    $('.burgermenu').on('click', function(){
        $('.mobnavhead').slideToggle('fast');
    })

})